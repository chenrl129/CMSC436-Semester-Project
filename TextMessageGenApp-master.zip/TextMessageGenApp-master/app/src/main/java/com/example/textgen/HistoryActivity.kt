package com.example.textgen

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import java.util.*

data class GenerationData(
    val uid: String,
    val input: String,
    val output: String,
//    val createdAt: Date
)

class HistoryActivity : AppCompatActivity() {
    private companion object {
        private const val TAG = "HISTORY_ACTIVITY"
    }

    private lateinit var recyclerView: RecyclerView

    private lateinit var mFirestore: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        Log.d(TAG, "onCreate called")
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        // set up recycler view
        recyclerView = findViewById<RecyclerView>(R.id.history_recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(this)

        getHistory()

//        Make an API call to get the history of the user and display it in a list view
//        Create a list view and display the history of the user
    }

    private fun getHistory() {
        val currentUserUid = FirebaseAuth.getInstance().currentUser?.uid
        mFirestore = FirebaseFirestore.getInstance()
        if (currentUserUid != null) {
            val query = mFirestore.collection("generations")
                .whereEqualTo("uid", currentUserUid)

            query.get()
                .addOnSuccessListener { documents ->
                    val data = documents.map { document ->
                        GenerationData(
                            document.data["uid"] as String,
                            document.data["input"] as String,
                            document.data["output"] as String)
                    }
                    recyclerView.adapter = OutputRecyclerAdapter(data)
                    Log.d(TAG, "Data: $data")
//                    for (document in documents) {
//                        Log.d(TAG, "${document.id} => ${document.data}")
//                    }

                }
                .addOnFailureListener { exception ->
                    // Handle the error
                }
        } else {
            // Handle the case where there is no current user
        }
    }

    class OutputRecyclerAdapter(private val data: List<GenerationData>) : RecyclerView.Adapter<OutputViewHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OutputViewHolder {
            val linearLayout = LayoutInflater.from(parent.context)
                .inflate(R.layout.history_card_layout, parent, false) as LinearLayout
            return OutputViewHolder(linearLayout)
        }

        override fun onBindViewHolder(holder: OutputViewHolder, position: Int) {
            val data = data[position]
            holder.bind(data)
        }

        override fun getItemCount() = data.size
    }

    class OutputViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val outputTextView: TextView = itemView.findViewById(R.id.text_view)
//        private val inputTextView: TextView = itemView.findViewById(R.id.input_text)

        fun bind(data: GenerationData) {
            outputTextView.text = "prompt: ${data.input} \noutput: ${data.output}"
//            inputTextView.text = data.input
        }
    }
}