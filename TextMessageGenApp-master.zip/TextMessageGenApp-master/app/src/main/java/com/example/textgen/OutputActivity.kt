package com.example.textgen

import android.content.Intent
import android.icu.util.Output
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException


class OutputActivity : AppCompatActivity() {
    private companion object {
        private const val TAG = "OUTPUT_ACTIVITY"
    }
    var output = ""
    private lateinit var mFirestore: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        Log.d(TAG, "onCreate called")
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_output)

        val input = intent.getStringExtra("generationInput")
        output = intent.getStringExtra("generationOutput").toString()
        val outputText: TextView = findViewById(R.id.output_text)
        outputText.text = output
        outputText.movementMethod = ScrollingMovementMethod()

        val saveButton = findViewById<Button>(R.id.save_button)
        val nextButton = findViewById<Button>(R.id.next_button)
        saveButton.setOnClickListener {
            if (input != null && output != null) {
                Log.d(TAG, "print output1:$output")
                writeResponseToFirestore(input, output!!)
                // go back to MainActivity
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }
        }

        nextButton.setOnClickListener {
            if (input != null) {
                sendGenerationRequest(input)
            }
        }
    }

    private fun sendGenerationRequest(generationInput: String) {
        val client = OkHttpClient();
        val request = buildGptRequest(generationInput)
        val nextButton = findViewById<Button>(R.id.next_button)
        val saveButton = findViewById<Button>(R.id.save_button)
        nextButton.isEnabled = false
        saveButton.isEnabled = false
        nextButton.text = "Generating..."
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(OutputActivity.TAG, "onFailure called")
                e.printStackTrace()
            }
            override fun onResponse(call: Call, response: Response) {
                Log.d(OutputActivity.TAG, "onResponse called")
                val responseBody = response.body?.string()
                val jsonObject = JSONObject(responseBody)
                val choicesArr = jsonObject.getJSONArray("choices")
                val choicesHead = choicesArr.get(0).toString()
                val completion = JSONObject(choicesHead)
                val generationOutput = completion.get("text").toString()

                runOnUiThread {
                    // set text view to new output
                    val outputText = findViewById<TextView>(R.id.output_text);
                    outputText.text = generationOutput
                    output = outputText.text.toString()
                    nextButton.isEnabled = true
                    saveButton.isEnabled = true
                    nextButton.text = "Try Again"
                }
            }
        })
    }

    private fun buildGptRequest(generationInput: String): Request {
        val json = """
                {
                  "model": "text-davinci-003",
                  "prompt": "$generationInput",
                  "temperature": 0.7,
                  "max_tokens": 3657,
                  "top_p": 1,
                  "frequency_penalty": 0,
                  "presence_penalty": 0
                }
            """
        Log.d(OutputActivity.TAG, generationInput)
        Log.d(OutputActivity.TAG, json)
        val body = json.toRequestBody("application/json; charset=utf-8".toMediaType())
        return Request.Builder()
            .url("https://api.openai.com/v1/completions")
            .addHeader(
                "Authorization",
                "Bearer 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"
            )
            .addHeader("Content-Type", "application/json")
            .post(body)
            .build()
    }

    private fun writeResponseToFirestore(generationInput: String, generationOutput: String) {
        val user = FirebaseAuth.getInstance().currentUser
        mFirestore = FirebaseFirestore.getInstance()
        val data = hashMapOf(
            "uid" to user?.uid,
            "input" to generationInput,
            "output" to generationOutput,
            "createdAt" to FieldValue.serverTimestamp(),
        )
        mFirestore.collection("generations").add(data)
    }
}