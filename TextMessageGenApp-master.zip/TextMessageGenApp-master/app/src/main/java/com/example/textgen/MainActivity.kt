package com.example.textgen

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException

//import com.openai.api.*

class MainActivity : AppCompatActivity() {
    private companion object {
        private const val TAG = "MAIN_ACTIVITY"
    }

    private lateinit var mFirestore: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        Log.d(TAG, "onCreate called")
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val inputText = findViewById<EditText>(R.id.editText)

        val buttonClick = findViewById<Button>(R.id.button)
        buttonClick.setOnClickListener {
            val generationInput = inputText.text.toString()
            sendGenerationRequest(generationInput)
        }

        val historyClick = findViewById<Button>(R.id.button2)
        historyClick.setOnClickListener {
            val intent = Intent(this, HistoryActivity::class.java)
            startActivity(intent)
        }
    }

    private fun sendGenerationRequest(generationInput: String) {
        val client = OkHttpClient();
        val button = findViewById<Button>(R.id.button)
        button.isEnabled = false
        button.text = "Generating..."
        val historyClick = findViewById<Button>(R.id.button2)
        historyClick.isEnabled = false
        val intent = Intent(this, OutputActivity::class.java)
        val request = buildGptRequest(generationInput)
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure called")
                e.printStackTrace()
            }
            override fun onResponse(call: Call, response: Response) {
                Log.d(TAG, "onResponse called")
                val responseBody = response.body?.string()
                val jsonObject = JSONObject(responseBody)
                val choicesArr = jsonObject.getJSONArray("choices")
                val choicesHead = choicesArr.get(0).toString()
                val completion = JSONObject(choicesHead)
                val generationOutput = completion.get("text").toString()

                runOnUiThread {
                    button.isEnabled = true
                    button.text = "Submit"
                    historyClick.isEnabled = true
                }
                // start output activity passing generation input and output
                intent.putExtra("generationInput", generationInput)
                intent.putExtra("generationOutput", generationOutput)
                startActivity(intent)
            }
        })
    }

    private fun buildGptRequest(generationInput: String): Request {
        val json = """
                {
                  "model": "text-davinci-003",
                  "prompt": "$generationInput",
                  "temperature": 0.7,
                  "max_tokens": 3657,
                  "top_p": 1,
                  "frequency_penalty": 0,
                  "presence_penalty": 0
                }
            """
        Log.d(TAG, generationInput)
        Log.d(TAG, json)
        val body = json.toRequestBody("application/json; charset=utf-8".toMediaType())
        return Request.Builder()
            .url("https://api.openai.com/v1/completions")
            .addHeader(
                "Authorization",
                "Bearer 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"
            )
            .addHeader("Content-Type", "application/json")
            .post(body)
            .build()
    }

    fun writeResponseToFirestore(generationInput: String, generationOutput: String) {
        val user = FirebaseAuth.getInstance().currentUser
        mFirestore = FirebaseFirestore.getInstance()
        val data = hashMapOf(
            "uid" to user?.uid,
            "input" to generationInput,
            "output" to generationOutput,
            "createdAt" to FieldValue.serverTimestamp(),
        )
        mFirestore.collection("generations").add(data)
    }
}