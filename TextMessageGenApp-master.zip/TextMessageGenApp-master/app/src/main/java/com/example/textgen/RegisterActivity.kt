package com.example.textgen

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.cardview.widget.CardView
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import java.lang.Exception

class RegisterActivity : AppCompatActivity() {
    private lateinit var googleSignInClient: GoogleSignInClient
    private lateinit var firebaseAuth: FirebaseAuth

    private companion object {
        private const val RC_CODE = 100
        private const val TAG = "GOOGLE_SIGNIN"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val googleSignInOptions = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(this.resources.getString(R.string.default_web_client_id))
            .requestEmail()
            .build()
        googleSignInClient = GoogleSignIn.getClient(this, googleSignInOptions)

        firebaseAuth = FirebaseAuth.getInstance()

        var cardView = findViewById<CardView>(R.id.Signin)
        cardView.setOnClickListener{ view: View? ->
            Toast.makeText(this, "Logging In", Toast.LENGTH_SHORT).show()
            val intent = googleSignInClient.signInIntent
            startActivityForResult(intent, RC_CODE)
        }
    }

    //
    // Button click sign in activity -> start google auth task and wait for result
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == RC_CODE) {
            val accountTask = GoogleSignIn.getSignedInAccountFromIntent(data)
            try {
                val account = accountTask.getResult(ApiException::class.java)
                firebaseGoogleAuth(account.idToken!!)
            } catch (e: Exception) {
                Log.d(TAG, "onActivityResult: ${e.message}")
            }
        }
    }

    //
    // Sign in with credential and get user object
    private fun firebaseGoogleAuth(authToken: String) {
        val credential = GoogleAuthProvider.getCredential(authToken, null)
        firebaseAuth.signInWithCredential(credential).addOnCompleteListener(this) { task ->
            if (task.isSuccessful) {
                val user = firebaseAuth.currentUser
                onAuthed(user)
            } else {
                Log.d(TAG, "Signin Failure", task.exception)
                onAuthed(null)
            }
        }
    }

    //
    // Start main activity when user is authed
    private fun onAuthed(user: FirebaseUser?) {
        Log.d(TAG, "onAuthed")
        if (user == null) {
            Log.d(TAG, "User null")
            return
        }

        Log.d(TAG, "Got user")
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}